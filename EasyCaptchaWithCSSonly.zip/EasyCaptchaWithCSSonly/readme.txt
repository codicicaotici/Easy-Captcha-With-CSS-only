Create a Simple Captcha Script Using PHP

Easy Captcha with CSS only
	
	NO javascript 
	NO $_SESSION
	NO graphics libraries

Free domain code
Usable without limits and in any project

Enjoy !!!!

by codicicaotici@gmail.com

